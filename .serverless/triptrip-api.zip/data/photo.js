const axios = require('axios')
const fs = require('fs')
const key = 'AIzaSyDh5WZBxwE5PewnqjNC0rgZ3I8Hxpm9r4Q'
// const sleep = require('sleep')

const placeData = require('./place.json')['data']
const axios = require('axios')
const fs = require('fs')
const key = 'AIzaSyDh5WZBxwE5PewnqjNC0rgZ3I8Hxpm9r4Q'

writeData()

async function writeData () {
  const data = await getPhotos(placeData)
  const jsonContent = JSON.stringify({ data: data }, null, 2)
  fs.writeFileSync('./place_new.json', jsonContent, 'utf8')
}

async function getPhotos (data) {
  for (const place of data) {
    let photoReferences = place.photos
    let photoLinks = []
    for (const reference of photoReferences) {
      let url = `https://maps.googleapis.com/maps/api/place/photo?maxwidth=800&photoreference=${reference}&key=${key}`
      let response = await axios.get(url)
      let link = response.request.res.responseUrl
      photoLinks.push(link)
    }
    place.photos = photoLinks
  }
  return data
}

