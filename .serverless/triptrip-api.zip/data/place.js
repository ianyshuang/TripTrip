const placeData = require('./place.json')['data']
const fs = require('fs')

const newData = placeData.data.map(place => ({
  formatted_address: place.result.formatted_address || '',
  formatted_phone_number: place.result.formatted_phone_number || '',
  geometry: place.result.geometry || '',
  name: place.result.name || '',
  opening_hours: place.result.opening_hours ? place.result.opening_hours.weekday_text : '',
  place_id: place.result.place_id || '',
  photos: (!place.result.photos || place.result.photos.length === 0) ? [] : place.result.photos,
  rating: place.result.rating || '',
  reviews: (!place.result.reviews || place.result.reviews.length === 0) ? [] : place.result.reviews,
  types: place.result.types ? place.result.types : '',
  url: place.result.url ? place.result.url : '',
  website: place.result.website ? place.result.website : ''
}))

newData.forEach(place => {
  for (const review of place.reviews) {
    delete review['language']
    delete review['time']
  }
  for (let i = 0; i < place.photos.length; i++) {
    place.photos[i] = place.photos[i]['photo_reference']
  }
})
const jsonContent = JSON.stringify({ data: newData }, null, 2)
fs.writeFileSync('./place_new.json', jsonContent, 'utf8')

// getPhotoUrl('CmRaAAAAcyNx7K9x7Vi8s9fbY_pWi3LpUIVFnm1VxT0ZTxNqsicQaO_QUXBoJtwUx-JZKBNJ2MWOP5DMvrgaKBHtblB9lbmmR0psE9jWb7t5nD7ScmA7LNZq8VxhZaaJ3O8NExdNEhDqmEwWgxZslBiJsngmOXZyGhQDCROb9gtgP6h2y537nBIHQw2FwQ')

// async function getPhotoUrl (photoReference) {
//   const key = 'AIzaSyDh5WZBxwE5PewnqjNC0rgZ3I8Hxpm9r4Q'
//   const url = `https://maps.googleapis.com/maps/api/place/photo?maxwidth=800&photoreference=${photoReference}&key=${key}`
//   try {
//     const result = await axios.get(url)
//     const buf = new Buffer.from(result.data)
//     console.log(typeof buf)
//     // fs.writeFileSync('test.png', buf)
//   } catch (error) {
//     console.log(error)
//   }
// }
